﻿namespace CheckRebar
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxSYNX = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxHJLB = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxHNTQD = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxGJZJ = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxZXBHC = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxBHCHD = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxGAJZJ = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxLK = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxDPZDGS = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxLDSP1 = new System.Windows.Forms.TextBox();
            this.textBoxLDSP2 = new System.Windows.Forms.TextBox();
            this.textBoxLDSP3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxLDISP1 = new System.Windows.Forms.TextBox();
            this.textBoxLDISP2 = new System.Windows.Forms.TextBox();
            this.textBoxLDISP3 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(283, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(927, 657);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(919, 628);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1018, 561);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "使用年限";
            // 
            // comboBoxSYNX
            // 
            this.comboBoxSYNX.FormattingEnabled = true;
            this.comboBoxSYNX.Items.AddRange(new object[] {
            "50",
            "100"});
            this.comboBoxSYNX.Location = new System.Drawing.Point(127, 38);
            this.comboBoxSYNX.Name = "comboBoxSYNX";
            this.comboBoxSYNX.Size = new System.Drawing.Size(121, 23);
            this.comboBoxSYNX.TabIndex = 3;
            this.comboBoxSYNX.Text = "50";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "环境类别";
            // 
            // comboBoxHJLB
            // 
            this.comboBoxHJLB.FormattingEnabled = true;
            this.comboBoxHJLB.Items.AddRange(new object[] {
            "一",
            "二a",
            "二b",
            "三a",
            "三b"});
            this.comboBoxHJLB.Location = new System.Drawing.Point(127, 67);
            this.comboBoxHJLB.Name = "comboBoxHJLB";
            this.comboBoxHJLB.Size = new System.Drawing.Size(121, 23);
            this.comboBoxHJLB.TabIndex = 3;
            this.comboBoxHJLB.Text = "二a";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "砼强度(MPa)";
            // 
            // comboBoxHNTQD
            // 
            this.comboBoxHNTQD.FormattingEnabled = true;
            this.comboBoxHNTQD.Items.AddRange(new object[] {
            "<=C25",
            ">C25"});
            this.comboBoxHNTQD.Location = new System.Drawing.Point(127, 96);
            this.comboBoxHNTQD.Name = "comboBoxHNTQD";
            this.comboBoxHNTQD.Size = new System.Drawing.Size(121, 23);
            this.comboBoxHNTQD.TabIndex = 3;
            this.comboBoxHNTQD.Text = ">C25";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "箍筋直径(mm)";
            // 
            // comboBoxGJZJ
            // 
            this.comboBoxGJZJ.FormattingEnabled = true;
            this.comboBoxGJZJ.Items.AddRange(new object[] {
            "6",
            "8",
            "10",
            "12"});
            this.comboBoxGJZJ.Location = new System.Drawing.Point(127, 125);
            this.comboBoxGJZJ.Name = "comboBoxGJZJ";
            this.comboBoxGJZJ.Size = new System.Drawing.Size(121, 23);
            this.comboBoxGJZJ.TabIndex = 3;
            this.comboBoxGJZJ.Text = "8";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "最小保护层(mm)";
            // 
            // textBoxZXBHC
            // 
            this.textBoxZXBHC.Location = new System.Drawing.Point(141, 167);
            this.textBoxZXBHC.Name = "textBoxZXBHC";
            this.textBoxZXBHC.Size = new System.Drawing.Size(107, 25);
            this.textBoxZXBHC.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 201);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "保护层厚度(mm)";
            // 
            // textBoxBHCHD
            // 
            this.textBoxBHCHD.Location = new System.Drawing.Point(141, 198);
            this.textBoxBHCHD.Name = "textBoxBHCHD";
            this.textBoxBHCHD.Size = new System.Drawing.Size(107, 25);
            this.textBoxBHCHD.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "钢筋直径(mm)";
            // 
            // comboBoxGAJZJ
            // 
            this.comboBoxGAJZJ.FormattingEnabled = true;
            this.comboBoxGAJZJ.Items.AddRange(new object[] {
            "14",
            "16",
            "18",
            "20",
            "22",
            "25",
            "28",
            "32"});
            this.comboBoxGAJZJ.Location = new System.Drawing.Point(127, 252);
            this.comboBoxGAJZJ.Name = "comboBoxGAJZJ";
            this.comboBoxGAJZJ.Size = new System.Drawing.Size(121, 23);
            this.comboBoxGAJZJ.TabIndex = 3;
            this.comboBoxGAJZJ.Text = "25";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 286);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "梁宽(mm)";
            // 
            // comboBoxLK
            // 
            this.comboBoxLK.FormattingEnabled = true;
            this.comboBoxLK.Items.AddRange(new object[] {
            "400",
            "450",
            "500",
            "600",
            "700",
            "800",
            "900",
            "1000"});
            this.comboBoxLK.Location = new System.Drawing.Point(127, 281);
            this.comboBoxLK.Name = "comboBoxLK";
            this.comboBoxLK.Size = new System.Drawing.Size(121, 23);
            this.comboBoxLK.TabIndex = 3;
            this.comboBoxLK.Text = "600";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 313);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "单排最大根数";
            // 
            // textBoxDPZDGS
            // 
            this.textBoxDPZDGS.Location = new System.Drawing.Point(141, 310);
            this.textBoxDPZDGS.Name = "textBoxDPZDGS";
            this.textBoxDPZDGS.Size = new System.Drawing.Size(107, 25);
            this.textBoxDPZDGS.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(137, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "梁顶钢筋实配(cm2)";
            // 
            // textBoxLDSP1
            // 
            this.textBoxLDSP1.Location = new System.Drawing.Point(149, 10);
            this.textBoxLDSP1.Name = "textBoxLDSP1";
            this.textBoxLDSP1.Size = new System.Drawing.Size(76, 25);
            this.textBoxLDSP1.TabIndex = 4;
            // 
            // textBoxLDSP2
            // 
            this.textBoxLDSP2.Location = new System.Drawing.Point(149, 41);
            this.textBoxLDSP2.Name = "textBoxLDSP2";
            this.textBoxLDSP2.Size = new System.Drawing.Size(76, 25);
            this.textBoxLDSP2.TabIndex = 4;
            // 
            // textBoxLDSP3
            // 
            this.textBoxLDSP3.Location = new System.Drawing.Point(149, 72);
            this.textBoxLDSP3.Name = "textBoxLDSP3";
            this.textBoxLDSP3.Size = new System.Drawing.Size(76, 25);
            this.textBoxLDSP3.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "梁底钢筋实配(cm2)";
            // 
            // textBoxLDISP1
            // 
            this.textBoxLDISP1.Location = new System.Drawing.Point(150, 15);
            this.textBoxLDISP1.Name = "textBoxLDISP1";
            this.textBoxLDISP1.Size = new System.Drawing.Size(76, 25);
            this.textBoxLDISP1.TabIndex = 4;
            // 
            // textBoxLDISP2
            // 
            this.textBoxLDISP2.Location = new System.Drawing.Point(150, 46);
            this.textBoxLDISP2.Name = "textBoxLDISP2";
            this.textBoxLDISP2.Size = new System.Drawing.Size(76, 25);
            this.textBoxLDISP2.TabIndex = 4;
            // 
            // textBoxLDISP3
            // 
            this.textBoxLDISP3.Location = new System.Drawing.Point(150, 77);
            this.textBoxLDISP3.Name = "textBoxLDISP3";
            this.textBoxLDISP3.Size = new System.Drawing.Size(76, 25);
            this.textBoxLDISP3.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBoxLDSP2);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.textBoxLDSP1);
            this.panel1.Controls.Add(this.textBoxLDSP3);
            this.panel1.Location = new System.Drawing.Point(22, 373);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(236, 108);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBoxLDISP3);
            this.panel2.Controls.Add(this.textBoxLDISP2);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.textBoxLDISP1);
            this.panel2.Location = new System.Drawing.Point(22, 509);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(236, 113);
            this.panel2.TabIndex = 7;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(867, 542);
            this.dataGridView1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 669);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBoxBHCHD);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxDPZDGS);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxZXBHC);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBoxGJZJ);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxHNTQD);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxHJLB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxLK);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBoxGAJZJ);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxSYNX);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "梁配筋构造";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxSYNX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxHJLB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxHNTQD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxGJZJ;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxZXBHC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxBHCHD;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxGAJZJ;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxLK;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxDPZDGS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxLDSP1;
        private System.Windows.Forms.TextBox textBoxLDSP2;
        private System.Windows.Forms.TextBox textBoxLDSP3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxLDISP1;
        private System.Windows.Forms.TextBox textBoxLDISP2;
        private System.Windows.Forms.TextBox textBoxLDISP3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

